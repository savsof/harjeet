// update base url ( http://localhost/default/ ). include slash at end
var base_url = "http://localhost/kaka_ikonetronics/";


function fade_hide(){
setTimeout(function(){
$(".message").fadeOut(5000);
},5000);
}
// submenu start here onclick show and hide
function submenuhide() {
			//alert('hi');
		document.getElementById("submenu1").style.display = "none";	
		document.getElementById("submenu2").style.display = "none";	
		document.getElementById("submenu3").style.display = "none";	
	    document.getElementById("submenu4").style.display = "none";	
	document.getElementById("submenu5").style.display = "none";	
	 }
function showsubmenu1() {
			//alert('hi');
		document.getElementById("submenu1").style.display = "block";
		document.getElementById("submenu2").style.display = "none";	
		document.getElementById("submenu3").style.display = "none";	
	    document.getElementById("submenu4").style.display = "none";			
			document.getElementById("submenu5").style.display = "none";	
	 }
function showsubmenu2() {
			//alert('hi');
		document.getElementById("submenu1").style.display = "none";
		document.getElementById("submenu2").style.display = "block";	
		document.getElementById("submenu3").style.display = "none";	
	    document.getElementById("submenu4").style.display = "none";			
			document.getElementById("submenu5").style.display = "none";	
	 }
function showsubmenu3() {
			//alert('hi');
		document.getElementById("submenu1").style.display = "none";
		document.getElementById("submenu2").style.display = "none";	
		document.getElementById("submenu3").style.display = "block";	
	    document.getElementById("submenu4").style.display = "none";	
 	document.getElementById("submenu5").style.display = "none";			
		
	 }	 
	 
function showsubmenu4() {
				document.getElementById("submenu5").style.display = "none";	
		document.getElementById("submenu1").style.display = "none";
		document.getElementById("submenu2").style.display = "none";	
		document.getElementById("submenu3").style.display = "none";	
	    document.getElementById("submenu4").style.display = "block";			
		
	 }
function showsubmenu5() {
			//alert('hi');
		document.getElementById("submenu1").style.display = "none";
		document.getElementById("submenu2").style.display = "none";	
		document.getElementById("submenu3").style.display = "none";	
 		document.getElementById("submenu4").style.display = "none";
	    document.getElementById("submenu5").style.display = "block";			
		
	 }	 	 
	// sub menu end 
	 
// get service provider name

function get_service_providername(getspname){ 
//alert(getspname);
$.ajax({

		url: base_url+"index.php/dashboard/choose_spname/"+getspname,
		success: function(data){ 
		$('#output_recordz').html(data);	
		}
		});

}
function sedatatravel(sp_id,serviceprovider_name)
{
///alert(serviceprovider_name);
document.getElementById("textdata").value=serviceprovider_name;
document.getElementById("dataid").value=sp_id;
$('#output_recordz').html('');	
}	 
		
/// category 
function suprsubcate(cate_id) {
$.ajax({

		url: base_url+"index.php/dashboard/select_supersubcategeory/"+cate_id,
		success: function(data){
		$('#subcates').append(data);
		}
		});

}	 

function prodquantity(aa,bb){
	//alert(aa);alert(bb);
	 elemA =	aa;
 elemB =  bb;

elemC=elemA * elemB;
        
//alert(elemC);
	document.getElementById("total").value=(elemC);
//$('#total').html('');
	
	
	
}	 
var kill=0;	 
	 
///get product for sale
//GET product By PROD id
////////////////////////////////////////////////////////////////////////////////////////------------------- product get by ID
function getproduct_forsaleby_id(proid){ 
//product name here;
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productid/"+proid,
		success: function(data){ 
		
		//$('#textdata0').html(data);	
		document.getElementById("textdata0").value=(data.trim());
		}
		});
	// prod quant here	
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productidqt/"+proid,
		success: function(data){ 
		
		//$('#textdata0').html(data);	
		document.getElementById("qa0").value=(data.trim());
			document.getElementById("hqa0").value=(data.trim());
		}
		});
		
			// prod sale per/unit here	
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productidsaleperunit/"+proid,
		success: function(data){ 
		
		//$('#textdata0').html(data);	
		document.getElementById("pr0").value=(data.trim());
		
		}
		});
		
			// prod id here	
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productid_id/"+proid,
		success: function(data){ 
	
		//$('#textdata0').html(data);	
		document.getElementById("dataid0").value=(data.trim());
		}
		});

	
}
////////////////////////////////////////////////////////////////////////////////////////------------------- product get by ID

////////////////////////////////////////////////////////////////////////////////////////------------------- product get by ID using for  add more
function getproduct_formultiplesaleby_id(proid,key){ 
//alert(key);
var autoprodid;
	var findprodid;
	var pValues = [];
	var pill=kill+1;
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productid_id/"+proid,
		success: function(fdata){ 
		//document.getElementById("dataid"+key+"").value=fdata;
		autoprodid=(fdata.trim());;
	
		for(var i=0; i<pill; i++){
							
									pValues[i] = document.getElementById("dataid"+i+"").value; 
								 }
//alert(autoprodid);


	 findprodid= pValues.indexOf(autoprodid);
//alert(findprodid);
		if(findprodid!='-1'){      //var id = errasedid.replace("dataid",""); it is for replace str words using javascript
if(findprodid=='1'){}else{
			$('#dataid'+key).val('');
			$('#textdata'+key).val('');
			
			document.getElementById("textdata"+key+"").value="";
			alert('This product is already added');
			}
		}
			
			else{
//product name here;
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productid/"+proid,
		success: function(data){ 
		
		//$('#textdata0').html(data);	
		document.getElementById("textdata"+key+"").value=(data.trim());
		}
		});
	// prod quant here	
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productidqt/"+proid,
		success: function(data){ 
		
		//$('#textdata0').html(data);	
		document.getElementById("qa"+key+"").value=(data.trim());
			document.getElementById("hqa"+key+"").value=(data.trim());
		}
		});
		
			// prod sale per/unit here	
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productidsaleperunit/"+proid,
		success: function(data){ 
		
		//$('#textdata0').html(data);	
		document.getElementById("pr"+key+"").value=(data.trim());
		
		}
		});
		
			// prod id here	
$.ajax({

		url: base_url+"index.php/dashboard/getchoose_productid_id/"+proid,
		success: function(data){ 
	
		//$('#textdata0').html(data);	
		document.getElementById("dataid"+key+"").value=(data.trim());
		}
		});
		
	
			}
		}
		});
		
		
		

	

}
////////////////////////////////////////////////////////////////////////////////////////------------------- product get by ID using for  add more
// get service provider name

function getproduct_forsale(getspname){ 
//alert(getspname);
$.ajax({

		url: base_url+"index.php/dashboard/choose_product/"+getspname,
		success: function(data){ 
		$('#output_recordz').html(data);	
		}
		});

}


function setdatatravel(product_id,prod_id,product_name,sale_price_per_unit,quat_aval,dataid)
{
	//alert('hi');
	var findprodid;
	var pValues = [];
	//alert(prod_id);
var pill=kill+1;
for(var i=0; i<pill; i++){

	 pValues[i] = document.getElementById("dataid"+i+"").value; 
}
	 findprodid= pValues.indexOf(prod_id);

		if(findprodid!='-1'){      //var id = errasedid.replace("dataid",""); it is for replace str words using javascript

			$('#dataid0').val('');
			$('#textdata0').val('');
			$('#qa0').val('');
			document.getElementById("textdata0").value="";
			alert('This product is already added');
			}
			else{
		document.getElementById("proiddata0").value=product_id;		
document.getElementById("textdata0").value=product_name;
document.getElementById("dataid0").value=prod_id;
document.getElementById("pr0").value=sale_price_per_unit;
document.getElementById("qa0").value=quat_aval;
document.getElementById("hqa0").value=quat_aval;
//document.getElementById("quantitybox0").value=quat_aval;      hqa is a actual quant available
$('#output_recordz').html('');	
			}
			

		
	
	
	
}		 
	function setdealervalue(dealerid,dealername){
	document.getElementById("dealerid").value=dealerid;	
	document.getElementById("dealername").value=dealername;	
$('#dealers').html('');	
}


function setdatatravel2(product_id,prod_id,product_name,sale_price_per_unit,key,quat_aval,dataid)
{
var errasedid;
	var findprodid;
	var pValues = [];
errasedid=dataid+key;

var pill=kill+1;
for(var i=0; i<pill; i++){
	//while($i <= pill){
	
	var ss;
	var dd =0;
	ss=dd+i;
	if(document.getElementById("dataid"+i+"")){
pValues[i] = document.getElementById("dataid"+i+"").value;
	}			

}
findprodid= pValues.indexOf(prod_id);
//alert(findprodid);
		if(findprodid!='-1'){  										////if they does not find same value then show -1 
																		//var id = errasedid.replace("dataid","");
			$('#dataid'+key).val('');
			$('#textdata'+key).val('');
			//$('#qa'+parseInt(key)).val('');
			document.getElementById("textdata"+key+"").value="";
		
			
			alert('This product is already added');
			}
			else{ 	
					document.getElementById("proiddata"+key+"").value=product_id;	
document.getElementById("textdata"+key+"").value=product_name;
document.getElementById("dataid"+key+"").value=prod_id;
document.getElementById("pr"+key+"").value=sale_price_per_unit;
document.getElementById("qa"+key+"").value=quat_aval;
document.getElementById("hqa"+key+"").value=quat_aval;
//document.getElementById("quantitybox"+key+"").value=quat_aval;
$('#output_record'+key).html('');	
				
				
			}
	

}		 
	 
	 
// add more fields
function addmore(prod_id,quant,unit) {
	
$.ajax({

		url: base_url+"index.php/dashboard/insertsale/"+prod_id+"/"+quant+"/"+unit,
		
		success: function(data){
		$('#addfields').append(data);
		}
		});

}		 

function delesale(saleid) {
	//alert(saleid);
$.ajax({

		url: base_url+"index.php/dashboard/deletesale/"+saleid,
		
		
			
		//document.getElementById("saleid").style.display = "none";	
	    success:function(data){
            if(data != ''){ //Only append data if there are some new
                timestamp = Math.round((new Date()).getTime() / 100); //Set timestamp to current time
                $('.addfields').append(data);
            }
		//location.reload();
		//$('#addfields').append(data);
		}
		});

}		 
	
function prodname_blank(kill){
	//alert(kill);
	document.getElementById("textdata"+kill+"").value='';
	 document.getElementById("pr"+kill+"").value='';
 document.getElementById("qa"+kill+"").value='';
 document.getElementById("hqa"+kill+"").value='';
 	 document.getElementById("dataid"+kill+"").value='';
	 
document.getElementById("output_recordz").style.display = "none";
document.getElementById("output_record"+kill+"").style.display = "none";
	
}	
function prodid_blank(kill){

 document.getElementById("textdata"+kill+"").value='';
 document.getElementById("qt"+kill+"").value='';
 document.getElementById("tp"+kill+"").value='';

	 document.getElementById("dataid"+kill+"").value='';
 document.getElementById("pr"+kill+"").value='';
 document.getElementById("qa"+kill+"").value='';
 document.getElementById("hqa"+kill+"").value='';
	document.getElementById("proiddata"+kill+"").value='';
document.getElementById("output_record"+kill+"").style.display = "block";
	
}	
function getproduct_forsale_anotherway(getspname,k_val){ 
//alert(getspname);

//alert(k_val);
var id='#output_record'+k_val;
//alert(id);
$.ajax({

		url: base_url+"index.php/dashboard/choose_product2/"+getspname+"/"+k_val,
		success: function(data){ //alert(data);
		$(id).html(data);	
		}
		});
		

}
var count_f=0;
function addup(){
	count_f+=1;
	kill+=1;
//alert(kill);
	var str="<div class='row' id='killme"+kill+"'><label class='col-sm-2' ><input type='text' name='product_id[]' readonly required id='proiddata"+kill+"' class='form-control' value='' autocomplete='off' placeholder='Product ID'></label><label class='col-sm-3' ><input type='text' name='sale_prod[]' onClick='prodid_blank("+kill+"),myFunction();'  id='textdata"+kill+"' onkeyup='getproduct_forsale_anotherway(this.value,"+kill+")'  class='form-control' value='' autocomplete='off' placeholder='Product Name' ><input type='hidden' id='dataid"+kill+"'  name='prod_id[]' value=''></label><label class='col-sm-2' ><input type='text' name='sale_quantity[]'  id='qt"+kill+"' pattern='[0-9]{0,9}' onkeyup='saleprodtotal(qt"+kill+".value,pr"+kill+".value,"+kill+"),getfortotal(tp"+kill+"),calqantavail2(qt"+kill+".value,qa"+kill+".value,hqa"+kill+".value,"+kill+"),add_othercharges()' style='width:50%' class='col-sm-1 form-control'   autocomplete='off' placeholder='Quantity' onclick='javascript:myFunction();'><input type='text' name='quantity_pending[]' id='qa"+kill+"' onkeyup='saleprodtotal(qt"+kill+".value,pr"+kill+".value,"+kill+"),getfortotal(tp"+kill+")' style='width:50%;background-color:#04B404;color:#fff;'   class='col-sm-1 form-control' autocomplete='off' ><input type='hidden' value='' id='hqa"+kill+"'><input type='hidden' value='' id='alt"+kill+"'></label><label class='col-sm-2'><input type='text'  name='price_per_unit[]' id='pr"+kill+"' class='form-control'  autocomplete='off' placeholder='Price/unit'></label><label class='col-sm-2'><input type='text' readonly name='prtotal[]' id='tp"+kill+"'  class='form-control' value='' autocomplete='off'></label><div class='col-lg-1' ><a href=javascript:removeup('"+kill+"'); class='btn btn-danger'>Remove</a></div><div style='clear:both;'></div><label  class='col-sm-10'><div id='output_record"+kill+"'></div></label></div>	";
	
	$('#multi_products').append(str);
	
	
}
function removeup(ki){
	//alert(ki);
var newgrandtotal;
	var gtotal = document.getElementById("grandtotal").value;
	//alert(gtotal);
	    var remval = document.getElementById("tp"+ki+"").value;
	//	alert(remval);
	elemA =newgrandtotal;
	elemB =remval;
	elemC =gtotal;
		newgrandtotal=gtotal-remval;
		
		
			document.getElementById("grandtotal").value=(newgrandtotal);
			
	
	var id='#killme'+ki;
	$(id).remove();
	count_f-=1;
	
	add_othercharges(othercost.value,disval.value);
discountimplement(disval.value,grandtotal.value);
}	 
	 
function saleprodtotal(qt,pr,key){ 
//var remval = document.getElementById("qt"+key+"").value;
var actqantavil = parseFloat(document.getElementById("hqa"+key+"").value);
	 elemA =	qt;
 elemB =  pr;



if(qt > actqantavil){
elemC=actqantavil * elemB;
}
else{ 
elemC=elemA * elemB;
}

	//document.getElementById("tp'+kill+'").value=(elemC);
$('#tp'+key).val(elemC);
	
	
	
}

function getfortotal(tp){

	//alert('hi');
	var elems=0;
	 
for (i = 0; i < 50; i++) { 
var id="tp"+i;
//alert(id);
if(document.getElementById(id) !== null){
	elems += parseFloat(document.getElementById(id).value);
	}
}
//alert(elems);

document.getElementById("grandtotal").value=elems;
}


function add_othercharges(){
	
	var othr=document.getElementById('othercost').value;
	if(othr==""){
		
		othr=0;
	}
	var grant=document.getElementById('grandtotal').value;

	var dis=document.getElementById('disval').value;
	//var altotal=parseFloat(grant) + parseFloat(othr);
	
	//alert(othr);
	var grant_total=0;
	 elems=0;
for (i = 0; i < 50; i++) { 
var id="tp"+i;
//alert(id);
if(document.getElementById(id) !== null){
	elems += parseFloat(document.getElementById(id).value);
	}
    
	
}
grant_total=parseFloat(othr)+elems;

	//document.getElementById("acttotal").value=grant_total;
$('#grandtotal').val(grant_total);


discountimplement(disval.value,grandtotal.value);
}



function checkqantavail(qa0){
	//alert(qa0);
	if(qa0 == 0){ 
		$('#qt0').attr('readonly', true);
	}else{ $('#qt0').attr('readable', true); }
		
	
}

function calqantavail(qt0,qa0,hqa,key){
if(parseInt(qt0) >= parseInt(qa0) ){ 

elemF =hqa;
			elemG =qt0;
			elemH=elemF-elemG;
			$("#qa0").val(elemH); 
	if(parseInt(qt0) > parseInt(hqa) ){ $("#qt0").val(hqa);  $("#qa0").val('0'); }
} else{ 

var quantpending;
	var qavail = document.getElementById("hqa0").value;
	 
	elemA =quantpending;
	elemB =hqa;
	elemC =qt0;
	elemA=elemB-elemC;
	//alert(elemA);
	if(elemA=='0'){ $("#qa0").val("0"); $("#qt0").val(hqa);   }else{
	document.getElementById("qa0").value=(elemA); }
	}
}
/// it is using in add more fields


function calqantavail2(qt,qa,hqa,key){
if(parseInt(qt) >= parseInt(qa) ){ 

			elemF =hqa;
			elemG =qt;
			elemH=elemF-elemG;
			$("#qa"+key).val(elemH); 
	if(parseInt(qt) > parseInt(hqa) ){ $("#qt"+key).val(hqa);  $("#qa"+key).val('0'); }
	} 

else{ 
var quantpending;
	var qavail = document.getElementById("hqa"+kill+"").value;
	 
	elemA =quantpending;
	elemB =hqa;
	elemC =qt;
	elemA=elemB-elemC;
	//alert(elemA);
	if(elemA=='0'){ $("#qa"+key).val("0"); $("#qt"+key).val(hqa);   }else{
document.getElementById("qa"+key+"").value=(elemA);
	}
}

add_othercharges(othercost.value,disval.value);
discountimplement(disval.value,grandtotal.value);
}



function discountimplement(){
var disval=document.getElementById('disval').value;
var othr=document.getElementById('othercost').value;
	if(disval==""){
		
		disval=0;
	}
	var grant=document.getElementById('grandtotal').value;

	var dis=document.getElementById('disval').value;
	//var altotal=parseFloat(grant) + parseFloat(othr);
	
	//alert(othr);
	var grant_total=0;
	 elems=0;
for (i = 0; i < 50; i++) { 
var id="tp"+i;
//alert(id);
if(document.getElementById(id) !== null){
	elems += parseFloat(document.getElementById(id).value);
	}
    
	
}
other_total=elems+parseFloat(othr);
grant_total=other_total-parseFloat(disval);

	//document.getElementById("acttotal").value=grant_total;
$('#grandtotal').val(grant_total);

//add_othercharges(othercost.value,disval.value);
}


$(document).ready(function() {
    $('#qt'+kill).keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
});









	 
