<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
:selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #D1D1D1;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 30;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
		
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

  
<div id="container">	
<H2>WELCOME TO SIGNUP FORM</h2>
    <div class="panel panel-default">
    <form method="post" action="<?php echo site_url('Pass_controller');?>">
    
    <div class="panel-body">
    <div class="form-group">
    <label for="username">user name:</label>
    <input type="text" class="form-control" name="username" required id="username">
     <label for="password">password:</label>
    <input type=password" class="form-control" name="password" required id="password">
    <label for="email">email:</label>
    <input for="email" class="form-control" name="email" required id="email">
   <label for="contactno">contactno:</label>
   <input type="contactno" class="form-control" name="contactno" required id="contactno">
   <label for="category">category:</label>
   <input type="category" class="form-control" name="category" required id="category">
   <label for="status">status:</label><br>
   <select name="status">
   <option value="user"<?php if($status='user' ){ echo 'selected';}?>>user</option>
    <option value="admin"<?php if($status='admin'){ echo 'selected';}?>>admin</option>
</select>
   <button type="submit" class="btn btn-default">Submit</button>
</div>
</div>
</div>
</form>

	 <p><a href="<?php echo site_url('Pass_controller/main_new/') ?>">USER-LIST</a>.</p>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>



</body>

 <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <form method="post" action="">
        <p>*********ADMIN*********</p>
              <label for="">user_name:-</label>
    <input type="user_name" class="form-control" name="user_name" required id="user_name">
     <label for="password">password:-</label>
    <input type="password" class="form-control" name="password" required id="password"><br>
    <label for="date">date:-</label>
    <input type="text" class="form-control" value="<?php echo date('d-m-Y',time()) ?>" name="date" required  ><br>
    <button type="show detail" class="btn btn-default">show detail</button>
	</form>
        </div>
       
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
</html>


