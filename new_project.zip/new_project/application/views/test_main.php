
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<head>

<body>


<a href="<?php echo site_url('Pass_controller/show'); ?>"class="btn btn-success">dashboard</a><br><br>
<form action="<?php echo site_url('Pass_controller/nav_list/'); ?>" method="POST">
--select--
 <select name="search_type">
     <option value="username">username</option>
    <option value="email">email</option>
   </select>
  
    <input type="text" name="search" placeholder="search">
 
   <button type="submit" class="btn btn-success">search</button>
   <a href="<?php echo site_url('Pass_controller/file_download'); ?>"class="btn btn-success">csv file record</a>
   <a href="<?php echo site_url('Pass_controller/download'); ?>" class="btn btn-success">pdf file record</a>

 
</form>
 <br><br>
<table class="table table-bordered">
<tr><td>username</td>
<td>password</td>
<td>email</td>
<td>contactno</td>
<td>status</td>
<td>category</td>
<td>action </td>
<td>action </td>
<td>action </td>
<td>action</td>

</tr>
<?php 
if(count($result)==0){
	?>
<tr>
 <td colspan="6"><?php echo $this->lang->line('no_record_found');?></td>
</tr>	
	
	
	
<?php } ?>
<?php
foreach($result as $key => $row){
?>
<tr>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['password'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['contactno'];?></td>
<td><?php echo $row['status'];?></td>
<td><?php echo $row['category'];?></td>
<td><a href="<?php echo site_url('Pass_controller/get_new/'.$row['u_id']); ?>"class="btn btn-default">view</a></td>
<td><a href="<?php echo site_url('Pass_controller/edit_new/'.$row['u_id']); ?>" class="btn btn-default">edit</a></td>
<td><a href="<?php echo site_url('Pass_controller/remove/'.$row['u_id']); ?>" class="btn btn-default">delete</a></td>
<td>
<a href="<?php echo site_url('Pass_controller/product_download/'.$row['u_id']); ?>" class="btn btn-info">pdf</a>
<a href="<?php echo site_url('Pass_controller/csvdownload/'.$row['u_id']); ?>" class="btn btn-info">csv</a>
<a href="<?php echo site_url('Pass_controller/generateexcelreports/'.$row['u_id']); ?>" class="btn btn-info">excel</a>
</td>

</tr>

<?php
}  ?>
</table>
<!-- page limitation start here pagination --->
     <span style="padding:20px;">
        <?php
        	if($limit== '0'){
        
if(($limit-($this->config->item('number_of_rows')))>=0){ $back=$limit-($this->config->item('number_of_rows')); } ?>


<?php
 $next=$limit+($this->config->item('number_of_rows'));  ?>

<a href="<?php echo site_url('Pass_controller/main_new/'.$next);?>" class="btn btn-success">Next</a>

<?php }

else {
if(($limit-($this->config->item('number_of_rows')))>=0){ $back=$limit-($this->config->item('number_of_rows')); }else{ $back='0'; } 

if(($limit-($this->config->item('number_of_rows')))>=0){ $back=$limit-($this->config->item('number_of_rows')); }else{ $back='0'; } ?>
<a href="<?php echo site_url('Pass_controller/main_new/'.$back);?>" class="btn btn-danger">Back</a>
&nbsp;&nbsp;
<?php

 $next=$limit+($this->config->item('number_of_rows'));  ?>

<a href="<?php echo site_url('Pass_controller/main_new/'.$next);?>" class="btn btn-danger">Next</a></p>

<?php } ?>

<!--page limitation end here-->
<a href="<?php echo site_url('Pass_controller/'); ?>"class="btn btn-success">FORM</a>


</body>

</head>
</html>
	




