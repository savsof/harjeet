<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div class="container">
    <form method="post" action="<?php echo site_url('Last_controller/'); ?>">
  <label for="username">username:-</label>
<input type="text" class="form control" name="username" value="<?php echo $result=['username']; ?>">
<label for="password">password:-</label>
<input type="text" class="form-control" name="password" value="">


</form>
</div>
</body>
</html>





	
	




