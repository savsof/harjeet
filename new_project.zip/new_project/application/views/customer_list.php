<html lang="en">
<head>
  <title>customer record</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 
<div class="container">
    <div class="panel panel-default">
    <form method="post" action="<?php echo site_url('Third_controller/customer_list/'.$result['c_id']);?>">
     <div class="panel-body">
    <div class="form-group">
    <label for="food_name">food_name:</label>
    <input type="text" class="form-control" name="food_name" value="<?php echo $result['food_name']; ?>">
    <label for="food_prize">food_prize:</label>
   <input type="text" class="form-control" name="food_prize" value="<?php echo $result['food_prize']; ?>">
 <label for="address">address:</label>
   <input type="text" class="form-control" name="address" value="<?php echo $result['address']; ?>">
    <label for="feedback"><feedback:</label>
 <input type="text" class="form-control" name="feedback" value="<?php echo $result['address']; ?>">
     <button type="submit" class="btn btn-default">Submit</button>
	</div>
	</div>
    	</form>
  </div>
</div>

</body>
</html>

