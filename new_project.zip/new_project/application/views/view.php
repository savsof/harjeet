<html lang="en">
<head>
  <title>student record</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 
<div class="container">
    <div class="panel panel-default">
    <form>
     <div class="panel-body">
    <div class="form-group">
    <label for="studentname">student Name:</label>
    <input type="text" class="form-control" name="studentname" value="<?php echo $result['studentname']; ?>" readonly >
    <label for="age">age:</label>
    <input type="text"  name="age" class="form-control" value="<?php echo $result['age']; ?>" readonly>  
    <label for="gender">gender:</label>
    <input type="text"  name="gender" class="form-control" value="<?php echo $result['gender']; ?>" readonly>  
     <label for="mobileno">mobileno:</label>
     <input type="text"  name="address" class="form-control" value="<?php echo $result['mobileno']; ?>" readonly> 
     <label for="address">address:</label>
     <input type="text" name="mobileno" class="form-control" value="<?php echo $result['address']; ?>"  readonly>  
  
	</div>
	</div>
    	</form>
  </div>
</div>

</body>
</html>

