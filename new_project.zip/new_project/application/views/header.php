<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>welcome to php</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div id="container">
	<h1>Welcome to php!</h1>

<div id="body">
	<form method="post" action="<?php echo site_url('Login');?>">
		<div class='contact'><h1>HELLO EVERYONE</h1></div>
	<div class="panel panel-default" id="contact">
<div class="panel-body">
	
	<div class="form">
	<div class="form-group">
    <label for="studentname">student Name:</label>
    <input type="studentname" name="studentname" required id="studentname">
    <label for="Last Name">class:</label>
    <input type="class"  name="class" required  id="class">
    <label for="rollno">rollno:</label>
    <input type="rollno"  name="rollno" required  id="rollno">
     <label for="batch">batch:</label>
    <input type="batch"  name="batch" required  id="batch">
    </div>
    <br/>
</div>
  <div class="form1">
    <label for="course">course:</label>
    <input type="course"  name="course" required  id="course">
    <label for="email">email:</label>
    <input type="email"  name="email" required  id="email">
    <label for="password">password:</label>
    <input type="password"  name="password" required  id="password">
     <label for="address">address:</label>
    <input type="address"  name="address" required  id="address">
    
  </div>
<br/>
    <label for="contactno">contactno:</label>
    <input type="contactno" name="contact" required  id="contactno">
    <label><input type="checkbox"> Remember me</label>
    <button type="submit" class="btn btn-default">Submit</button>
	</form>

   <p>If you are exploring CodeIgniter for the very first time<a href="<?php echo site_url('Login/add_new') ?>">Link</a>.</p>
	

	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
</div>
</body>
</html>
<html>
