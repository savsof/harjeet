<html lang="en">  
<head>
  <style>
 
</style>
</head>
<title>convert to pdf file in Codeigniter using MPDF Library</title>

<body>


<div class="table">
    <table style="border:20px solid black;width:100%;">
       
      <tr class="pdf_border">
         <th style="border:10px solid red;">username</th><br>
         <th style="border:10px solid green">email</th> 
         <th style="border:10px solid blue">contactno</th>
         <th style="border:10px solid pink">status</th>                      
                
      </tr>
      
       
<?php 
if(count($result)==0){
	?>
<tr>
 <td colspan="6"><?php echo $this->lang->line('no_record_found');?></td>
</tr>	
	
	
	
<?php } ?>
<?php
foreach($result as $key => $row){
?>
<tr>
 <td style="border:10px solid red"><?php echo $result['username']; ?></td>
 <td style="border:10px solid green"><?php echo $result['email']; ?></td> 
 <td style="border:10px solid blue"><?php echo $result['contactno']; ?></td>
 <td style="border:10px solid pink"><?php echo $result['status']; ?></td>
			            
  
</tr>

<?php
}  ?>
</table>
   				
</div> 
</body>
</html>
