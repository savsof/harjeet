
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
 
<head>

<body>
<table class="table table-bordered">
<tr><td>studentname</td>
<td>Class</td>
<td>roll no</td>
<td>Batch</td>
<td>Email</td>
<td>course</td>
<td>Address</td>
<td>contactno</td>
</tr>
<?php
print_r($result);die;
foreach($result as $row){
    



?>
<tr>
<tr><td><?php echo $row['studentname'];?></td>
<td><?php echo $row['class'];?></td>
<td><?php echo $row['rollno'];?></td>
<td><?php echo $row['betch'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['course'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['contactno'];?></td>

<?php
}  ?>
</table>




</body>


</head>
</html>
	

