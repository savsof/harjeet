<!--enquiry--->

<script type="text/javascript" src="<?php echo base_url();?>/js/basic.js"></script>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<br>
<?php 
if($resultstatus){ echo "<div class='alert alert-success'>".$resultstatus."</div>"; }?>
<div class="col-lg-4">
 <label>Report by</label>
		                                        <select name="searchby" onChange="javascript:change_report(this.value);" class="form-control">
<option value="">--Please select--</option>
<option value="enquiry"<?php if($lasturi=='enquiry'){ echo 'selected';}?>>Enquiry</option>
<option value="Admission"<?php if($lasturi=='Admission'){ echo 'selected';}?>>Admission</option>
<option value="Fee"<?php if($lasturi=='Fee'){ echo 'selected';}?>>Fee Management</option>
<option value="Account"<?php if($lasturi=='Account'){ echo 'selected';}?>>Account Management</option>
<option value="General">General</option>


</select>
</div>

<div class="col-lg-12" id="enquiry" style="<?php if($lasturi=='enquiry'){?>display:block;<?php }else{ ?>display:none;<?php } ?>">
<div class="panel panel-default" style="margin-top: 20px;">
                        <div class="panel-heading">
                           Enquiry Report
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

<form method="post"  id="myformm"  action="<?php echo site_url('report/enquiry_report');?>" onSubmit="return enquiryys();">
<div id="enquiryy">
<?php //echo "<pre>";print_r($_POST);die;
if(isset($_POST['enquiryy']) && $_POST['enquiryy']!=''){
$enval=str_replace("hasDatepicker","",$_POST['enquiryy']);
$encheckedarr=array();

if(!isset($_POST['enstudent_name'])){
$encheckedarr[]="#enstudent_name";
}   

if(!isset($_POST['encontact_no'])){
$encheckedarr[]="#encontact_no";
}
if(!isset($_POST['encourse_code'])){
$encheckedarr[]="#encourse_code";
}
if(!isset($_POST['enfollowup'])){
$encheckedarr[]="#enfollowup";
}

if(!isset($_POST['enenquiry_statuss'])){
$encheckedarr[]="#enenquiry_statuss";
}
if(!isset($_POST['ensourse_type'])){
$encheckedarr[]="#ensourse_type";
}
if(!isset($_POST['enbatch_time'])){
$encheckedarr[]="#enbatch_time";
}

echo $enval;
foreach($encheckedarr as $cken => $cvalen){
?>
<script>
$('<?php echo $cvalen;?>').prop('checked', false);
</script>
<?php
}
}else{ //echo "exit";echo "<pre>";print_r($encheckedarr);die;
?>

<div class="col-lg-12">
<div class="col-lg-3">
<div class="form-group">

<label>From Date</label>
<input type="text"   id="datepicker" name="from_datee" value="<?php echo  date('d-m-Y', strtotime("-1 months"));?>"  class="form-control" style="width:70%;">
</div>
</div>
<div class="col-lg-3">
<div class="form-group">
<label>To Date</label>
<input type="text"   id="datepicker1"  name="to_datee" value="<?php echo date('d-m-Y',time());?>"  class="form-control" style="width:70%;">
</div></div>
<div class="col-lg-3" style=""><div class="form-group">
<label>Status</label>
<select name="enquiry_statuss"class="form-control" id="en1" style="width:70%;">
<option value="All">All</option>
<option value="Lead" <?php if($status=='Lead'){ echo 'selected';}?> >Lead</option>
<option value="Admitted" <?php if($status=='Admitted'){ echo 'selected';}?> >Admitted</option>
<option value="Archive" <?php if($status=='Archive'){ echo 'selected';}?> >Archive</option> 
</select>
</div>
</div>
<div class="col-lg-3" style=""><div class="form-group">
<label>Followup</label>
 <select name="Followup" id="en2"  class="form-control" style="width:70%;">
<option value="All">All</option>
<option value="followup0"  <?php if($status=='followup0'){ echo 'selected';}?>>Followup 0</option>
<option value="followup1"  <?php if($status=='followup1'){ echo 'selected';}?>>Followup 1</option>
<option value="followup2"  <?php if($status=='followup2'){ echo 'selected';}?>>Followup 2</option>
<option value="followup3"  <?php if($status=='followup3'){ echo 'selected';}?>>Followup 3</option>
</select>
</div> 
</div>


</div>


<div class="col-lg-12">
<div class="col-lg-3"><div class="form-group">
<label>Course Code</label>
<select name="enquiry_course" id="en3"  class="form-control" style="width:70%;">
<option value="All">All</option>
<?php foreach($course as $value){ ?>
	<option value="<?php echo $value['course_id']; ?>"> <?php echo $value['course_code']; ?></option>
	<?php } ?>
</select>
</div>
</div>

<div class="col-lg-3"><div class="form-group"style="">
<label>Source Type</label>
<select name="source_type" id="en4"  class="form-control" style="width:70%;">
<option value="All">All</option>
<option value="Online" <?php if($status=='Online'){ echo 'selected';}?>>Online</option>
<option value="Walk-In" <?php if($status=='Walk-In'){ echo 'selected';}?>>Walk-In</option>
<option value="Friends" <?php if($status=='Friends'){ echo 'selected';}?>>Friends</option>
<option value="Newspaper" <?php if($status=='Newspaper'){ echo 'selected';}?>>Newspaper</option>
<option value="Telephonic"<?php if($status=='Telephonic'){ echo 'selected';}?>>Telephonic</option>
<option value="Campaigns"<?php if($status=='Campaigns'){ echo 'selected';}?>>Campaigns</option>
<option value="Digital Marketing"<?php if($status=='Digital Marketing'){ echo 'selected';}?>>Digital Marketing</option>
<option value="Others"<?php if($status=='Others'){ echo 'selected';}?>>Others</option>                                            
                                             
                                              
</select>
</div>
</div>
<div class="col-lg-3"><div class="form-group" style="">
<label>Batch Time</label>
 <select name="batch_from_time" id="en5"  class="form-control" style="width:70%;">
<script type="text/javascript" src="<?php echo base_url();?>/js/basic.js"></script>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<br>
<?php 
if($resultstatus){ echo "<div class='alert alert-success'>".$resultstatus."</div>"; }?>
<div class="col-lg-4">
 <label>Report by</label>
		                                        <select name="searchby" onChange="javascript:change_report(this.value);" class="form-control">
<option value="">--Please select--</option>
<option value="enquiry"<?php if($lasturi=='enquiry'){ echo 'selected';}?>>Enquiry</option>
<option value="Admission"<?php if($lasturi=='Admission'){ echo 'selected';}?>>Admission</option>
<option value="Fee"<?php if($lasturi=='Fee'){ echo 'selected';}?>>Fee Management</option>
<option value="Account"<?php if($lasturi=='Account'){ echo 'selected';}?>>Account Management</option>
<option value="General">General</option>


</select>
</div>
<!--enquiry--->
<div class="col-lg-12" id="enquiry" style="<?php if($lasturi=='enquiry'){?>display:block;<?php }else{ ?>display:none;<?php } ?>">
<div class="panel panel-default" style="margin-top: 20px;">
                        <div class="panel-heading">
                           Enquiry Report
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

<form method="post"  id="myformm"  action="<?php echo site_url('report/enquiry_report');?>" onSubmit="return enquiryys();">
<div id="enquiryy">
<?php //echo "<pre>";print_r($_POST);die;
if(isset($_POST['enquiryy']) && $_POST['enquiryy']!=''){
$enval=str_replace("hasDatepicker","",$_POST['enquiryy']);
$encheckedarr=array();

if(!isset($_POST['enstudent_name'])){
$encheckedarr[]="#enstudent_name";
}   

if(!isset($_POST['encontact_no'])){
$encheckedarr[]="#encontact_no";
}
if(!isset($_POST['encourse_code'])){
$encheckedarr[]="#encourse_code";
}
if(!isset($_POST['enfollowup'])){
$encheckedarr[]="#enfollowup";
}

if(!isset($_POST['enenquiry_statuss'])){
$encheckedarr[]="#enenquiry_statuss";
}
if(!isset($_POST['ensourse_type'])){
$encheckedarr[]="#ensourse_type";
}
if(!isset($_POST['enbatch_time'])){
$encheckedarr[]="#enbatch_time";
}

echo $enval;
foreach($encheckedarr as $cken => $cvalen){
?>
<script>
$('<?php echo $cvalen;?>').prop('checked', false);
</script>
<?php
}
}else{ //echo "exit";echo "<pre>";print_r($encheckedarr);die;
?>

<div class="col-lg-12">
<div class="col-lg-3">
<div class="form-group">

<label>From Date</label>
<input type="text"   id="datepicker" name="from_datee" value="<?php echo  date('d-m-Y', strtotime("-1 months"));?>"  class="form-control" style="width:70%;">
</div>
</div>
<div class="col-lg-3">
<div class="form-group">
<label>To Date</label>
<input type="text"   id="datepicker1"  name="to_datee" value="<?php echo date('d-m-Y',time());?>"  class="form-control" style="width:70%;">
</div></div>
<div class="col-lg-3" style=""><div class="form-group">
<label>Status</label>
<select name="enquiry_statuss"class="form-control" id="en1" style="width:70%;">
<option value="All">All</option>
<option value="Lead" <?php if($status=='Lead'){ echo 'selected';}?> >Lead</option>
<option value="Admitted" <?php if($status=='Admitted'){ echo 'selected';}?> >Admitted</option>
<option value="Archive" <?php if($status=='Archive'){ echo 'selected';}?> >Archive</option> 
</select>
</div>
</div>
<div class="col-lg-3" style=""><div class="form-group">
<label>Followup</label>
 <select name="Followup" id="en2"  class="form-control" style="width:70%;">
<option value="All">All</option>
<option value="followup0"  <?php if($status=='followup0'){ echo 'selected';}?>>Followup 0</option>
<option value="followup1"  <?php if($status=='followup1'){ echo 'selected';}?>>Followup 1</option>
<option value="followup2"  <?php if($status=='followup2'){ echo 'selected';}?>>Followup 2</option>
<option value="followup3"  <?php if($status=='followup3'){ echo 'selected';}?>>Followup 3</option>
</select>
</div> 
</div>


</div>


<div class="col-lg-12">
<div class="col-lg-3"><div class="form-group">
<label>Course Code</label>
<select name="enquiry_course" id="en3"  class="form-control" style="width:70%;">
<option value="All">All</option>
<?php foreach($course as $value){ ?>
	<option value="<?php echo $value['course_id']; ?>"> <?php echo $value['course_code']; ?></option>
<option value="All">All</option>
                    <option value="08:00 AM">08:00 AM</option>
                     
                      <option value="09:00 AM">09:00 AM</option>
                      
                      <option value="10:00 AM">10:00 AM</option>
                      
                      <option value="11:00 AM">11:00 AM</option>
                      
                      <option value="12:00 PM">12:00 PM</option>
                      <option value="01:00 PM">01:00 PM</option>

                       <option value="02:00 PM">02:00 PM</option>

                       <option value="03:00 PM">03:00 PM</option>

                       <option value="04:00 PM">04:00 PM</option>

                       <option value="05:00 PM">05:00 PM</option>

                       <option value="06:00 PM">06:00 PM</option>

                       <option value="07:00 PM">07:00 PM</option>
 
 

</select>
</div> 
</div>

<div class="col-lg-3"><div class="form-group">
<button type="button" class="btn btn-info" onClick="eneneen()" style="margin-top:20px;">Dynamic Report</button>

</div>
</div>
<div class="col-lg-12">
<button type="button" onClick="enqu();" class="btn btn-success"style="margin-top:20px;">Generate Report</button>
</div>
</div>
</div>



<div style="clear:both"></div>
<?php 
 $logged_in=$this->session->userdata('logged_in');
 // print_R($logged_in);
 ?>

<?php if($logged_in['su']=="1" || $logged_in['su']=="5"){ ?>
<?php }else{ ?>
<?php } ?>










<form>
<div class="login-panel panel panel-default" id="enquiryyy" style="width:103%; display:none; margin-top:25px;margin-left: -17px;">
		<div class="panel-body"> 



    <label class="checkbox-inline">
    <input type="checkbox"  name="enstudent_name" id="enstudent_name" value="1" checked   >
candidate Name 
    </label>

 <label class="checkbox-inline">
    <input type="checkbox"  name="encontact_no" id="encontact_no" value="1" checked   >
Contact No.
    </label>
    <label class="checkbox-inline">
    <input type="checkbox" name="enenquiry_statuss" id="enenquiry_statuss" value="1" checked  >
Enquiry Status
    </label>
<label class="checkbox-inline">
  <input type="checkbox" name="enfollowup" id="enfollowup" value="enfollowup" value="1" checked  >
Followup
    </label>
 <label class="checkbox-inline">
             <input type="checkbox" name="encourse_code" id="encourse_code" value="1" checked  >
Course Code
</label>
 <label class="checkbox-inline">
             <input type="checkbox" name="ensourse_type" id="ensourse_type" value="1" checked  >
Sourse Type
</label>
<label class="checkbox-inline">
            <input type="checkbox" name="enbatch_time" id="enbatch_time" value="1" checked  >
Batch Time
</label>

  </form>

			


</div>

</div>




</div>

<textarea  style="visibility:hidden;" id="enquiryy_val" name="enquiryy"></textarea>

<?php 
}
?></div>

<div class="row" style="margin-top:-50px;">
<?php 
if(isset($encsvdatap)){
?>
<a href="javascript:enq();" class="btn btn-danger" style="margin-left:30px; margin-top:-13px;"><i class="fa fa-download" ></i> Export Excel</a>
<!--<a href="javascript:genrep_p();" class="btn btn-primary"><i class="fa fa-download" ></i> Download Photos</a>-->
<div class="table-responsive"><div style="clear:both"><br></div>
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="95%;">
<?php 

$encdata=explode("\r\n",$encsvdatap);
foreach($encdata as $k => $val){
if($k >= 1){
if($k==1){ ?><thead><?php }else{ ?><tbody> <?php } ?><tr><?php 
if($k==1){ 
foreach(explode(',',$val) as $kl => $v){ 
?>

<th><?php echo $v;?></th>
<?php
} 
}else{
foreach(explode(',',$val) as $kl => $v){ 
?>
<td><?php 
echo $v;?></td>
<?php
} 
}
?></tr><?php if($k==2){ ?></thead><?php }else{ ?></tbody> <?php }  
}
}
?>
</table>
</div>
<!---<a href="javascript:genrep();" class="btn btn-danger"><i class="fa fa-download" ></i> Generate Excel</a>-->
<?php 
}


?>
</div>
</div>
</div>

</form>


<!--
<hr> 
<h2>Report history</h2>
<table class="table table-hover">
<tr><th>Generated Date</th><th>Hash Key</th><th>Action</th></tr>
<?php foreach($report_history as $kreport => $reportval){ ?>
<tr>
<td><?php echo $reportval['generated_time'];?></td>
<td><?php echo $reportval['hashkey'];?></td>
<td><a href="<?php echo site_url('history/'.$reportval['rhid']);?>">Download</a></td>

</tr>
<?php } ?>
</table>
<?php if(count($report_history)==0){ echo "No saved history";}?>
-->


<!-- Trigger the modal with a button -->
<!--<a href="javascript:$('#myModal').modal('show');" >Q</a>-->

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">DB query </h4>
      </div>
      <div class="modal-body">
        <p><?php echo $query;?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<hr>

 
</div>
 
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );

function enq(){
$("#myformm").attr("action", "<?php echo site_url('report/enquiry_report/1');?>");
$("#myformm").submit();
}

function enqu(){
$("#myformm").attr("action", "<?php echo site_url('report/enquiry_report/enquiry');?>");
$("#myformm").submit();
}


function enquiryys(){
 
 
var did=$('#enquiryy').html();
  
$('#enquiryy_val').val(did);
return true;
}

</script>

<script>

function getsuglist(val,col,table,id,hid,rid,sid){
if(val != ''){
var formData = {id:id,val:val,col:col,table:table,hid:hid,rid:rid,sid:sid};
$.ajax({
		 type: "POST",
		 data : formData,
			url: "<?php echo site_url('result/getsuglist');?>",
		success: function(data){
		  $(sid).html(data);
		  $(sid).css('display','block');
			
			},
		error: function(xhr,status,strErr){
			//alert(status);
			}	
});


        }else{
		  $(sid).html('');
		  $(sid).css('display','none');
        }

}



function putval(hid,hidv,rid,ridv,sid,id){
 
if($(hid).val() == ''){

$(hid).val(hidv);
$(rid).html("<span class='filtered'  >"+ridv+"  <a href='#' onClick=\"removeitem(this,'"+hid+"','"+ridv+"');\" ><i class='fa fa-times'></i></a></span>");

}else{

$(hid).val($(hid).val()+','+hidv);
$(rid).html($(rid).html()+"<span class='filtered'   >"+ridv+" <a href='#' onClick=\"removeitem(this,'"+hid+"','"+ridv+"');\" ><i class='fa fa-times'></i></a></span>");

}
                          $(sid).html('');
		          $(sid).css('display','none');
                          $(id).val('');
		  
}

function removeitem(e,hid,ridv){
$(e).parent().remove();
var vals=$(hid).val().split(',');
 
vals.splice($.inArray(ridv, vals),1);
$(hid).val(vals.join(','));
}






</script>

<script>

 <?php 
 if(isset($_POST['from_datee'])){
 ?>
 $('#datepicker').val('<?php echo $_POST['from_datee'];?>');
 $('#datepicker1').val('<?php echo $_POST['to_datee'];?>');
 $('#en1').val('<?php echo $_POST['enquiry_statuss'];?>');
 $('#en2').val('<?php echo $_POST['Followup'];?>');
 $('#en3').val('<?php echo $_POST['enquiry_course'];?>');
 $('#en4').val('<?php echo $_POST['source_type'];?>');
 $('#en5').val('<?php echo $_POST['batch_from_time'];?>');


 <?php 
 }
 ?>
 setTimeout(function(){
  $( "#datepicker" ).datepicker();
 $( "#datepicker1" ).datepicker();
 console.log('hi');
 },100);
  </script>

<script>
$("document").ready(function() {

  $('.dropdown-menu').on('click', function(e) {
      if($(this).hasClass('dropdown-menu-form')) {
          e.stopPropagation();
      }
  });
});

</script>

<script>
var expanded = false;


function eneneen() {
var enquiryyy = document.getElementById("enquiryyy");
  if (!expanded) {
    enquiryyy.style.display = "block";
    expanded = true;
  } else {
    enquiryyy.style.display = "none";
    expanded = false;
  }

}

</script>

<script>

$('.datepicker').datepicker();

  </script>


<!-- end-->
