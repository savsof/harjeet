<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

 <nav class="navbar-inverse">
   <div class="container-fluid">
      <div class="navbar-header">
      </div>
     <ul class="nav navbar-nav">
 <li class="active"><a href="#">FORM</a></li>
      <li><a href="<?php echo site_url('Second_controller/') ?>">home</a></li>
        <li><a href="<?php echo site_url('Second_controller/nav_list/') ?>">about</a></li>
	  <li><a href="<?php echo site_url('Second_controller/nav_list') ?>">footer</a></li>
  </ul>
         
  
  </div>
</div>
    
  

  </div>
 </nav>
</body>
</html>


  








