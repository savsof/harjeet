<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<head>

<body>
<table class="table table-bordered">
<tr>
<td>username</td>
<td>password</td>
<td>action</td>
</tr>
<?php
if(count($result)==0)
{
?>
<tr>
 <td colspan="4"><?php echo $this->lang->line('no_record_found');?></td>
</tr>	
	
	
	
<?php } ?>
<?php
//print_r($result);die;
foreach($result as $row){
?>
<tr>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['password'];?></td>

<td><a href="<?php echo site_url('Last_controller/view_pdf/'.$row['a_id']); ?>" class="btn btn-dafault">pdf</a>
</td>
</tr>
<?php
}
?>
</table>
<td><a href="<?php echo site_url('last_controller/show'); ?>" class="btn btn-info">view</a></td>
</body>
</head>
</html>

