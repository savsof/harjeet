<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>HELLO EVERYONE</title>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

<!-- Bootstrap Date-Picker Plugin -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
</head>
<body>

<div id="container">	

<div id="body">
    <div class="panel panel-default">
    <form method="post" action="<?php echo site_url('Second_controller');?>">
    
    <div class="panel-body">
    <div class="form-group">
    <label for="product_name">product name:-</label>
    <input type="product_name" class="form-control" name="product_name" required id="product_name">
    <label for="quantity">quantity:-</label>
    <input type="quantity" class="form-control" name="quantity" required id="quantity">
    <label for="prize per/unit">prize per/unit:-</label>
    <input type="prize per/unit" class="form-control" name="prize_per_unit" required id="prize per/unit"><br/>
    <label for="description">description:</label>
    <textarea class="form-control" name="description" rows="5" id="description"></textarea>
    <label for="insert date">insert date:-</label>
    <input type="insert_date" class="form-control" name="insert_date"  id="datepicker" ></br>
  <label for="status">status:-</label><br>
   <select name="status">
   <option value="active"<?php if($status='active' ){ echo 'selected';}?>>active</option>
    <option value="unactive"<?php if($status='unactive'){ echo 'selected';}?>>unactive</option>
   </select>
    <button type="submit" class="btn btn-default">Submit</button>
</div>
</div>
</div>
</form>
 <span><a href="<?php echo site_url('Second_controller/nav_list/') ?>">next</a></span>
<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</body>
</div>
 <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <form method="post" action="">
        <p>*********ADMIN*********</p>
              <label for="">username:-</label>
    <input type="username" class="form-control" name="username" required id="username">
    <label for="email">email:-</label>
    <input type="email" class="form-control" name="email" required id="email">
    <label for="password">password:-</label>
    <input type="password" class="form-control" name="password" required id="password"><br>
    <label for="date">date:-</label>
    <input type="text" class="form-control" value="<?php echo date('d-m-Y',time()) ?>" name="date" required  >
    <button type="submit" class="btn btn-default">Submit</button>
	</form>
        </div>
       
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>


</div>
</html>


<script>
$(function(){
   $('#datepicker').datepicker({
      format: 'dd-mm-yyyy'
    });
});
</script>
<script>
function  Myfunction(){
	// console.log('dd'); 
	var formData = {val:'12'};
	$.ajax({
		 type: "POST",
		 data : formData,
			url: base_url + "index.php/second_controller/admin_list/",
		success: function(data){
		 
			},
		error: function(xhr,status,strErr){
			alert(status);
			}	
		});
	
}

</script>
