
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">



	<title>HELLO</title>
<style>
.body{

	height:50%;
	width:100%;

}
</style>

    </head>
	<body>
      <img src="<?php echo base_url('images/smile.gif');?>"/>
	</body>
</html>

