<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
 
<head>

<body>
<table class="table table-bordered">
<tr><td>food_name</td>
<td>food_prize</td>
<td>address</td>
<td>feedback</td>
</tr>
<?Php
print_r($result); die;
foreach($result as $row){
?>
<tr><td><?php echo $row['food_name']; ?></td>
<td><?php echo $row['food_prize']; ?></td>
<td><?php echo $row['address']; ?></td>
<td><?php echo $row['feedback'; ?></td>
</tr>
<?php
{ ?>
<table>
</head>
</body>

</html>
