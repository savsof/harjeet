<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>ADMIN PAGE</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
    <div id="container">	
<div id="body">
    <div class="panel panel-default">
    <form method="post" action="<?php echo site_url('Last_controller/');?>" enctype="multipart/form-data">     
    <div class="panel-body">
    <div class="form-group">
    <label for="username">username:-</label>
    <input type="text" class="form-control" name="username" required><br>
    <label for="password">password</label>
    <input type="password" class="form-control" name="password" required><br>
   
     <label for="category"> category</label><br>
     <input type="text" class="form-control" name="category" required><br>
    <button type="login" class="btn btn-success">login</button>

</div>
</div>
</div>
</form>
<p><a href="<?php echo site_url('last_controller/user_new') ?>">USER-LIST</a>.</p>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</body>
</html>
