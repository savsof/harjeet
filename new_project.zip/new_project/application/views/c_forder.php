<!DOCTYPE html> 
<html lang = "en">
 
   <head> 
      <meta charset = "utf-8"> 
      <title>CodeIgniter View Example</title> 
   </head> 
	
   <body> 
      <a href = 'display'>Click Here</a> to view the cookie.<br> 
      <a href = 'delete'>Click Here</a> to delete the cookie. 
   </body>
	
</html>


