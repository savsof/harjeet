<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<head>

<body>
<br><br>
<form action="<?php echo site_url('second_controller/nav_list/');?>" method="POST">
--select--
 <select name="search_type">
     <option value="product_id">product_id</option>
    <option value="product_name">product_name</option>
   </select>
  
    <input type="text" name="search" placeholder="search">
 
   <button type="submit" class="btn btn-success">search</button>
<select name="status">
     <option value="active">active</option>
    <option value="unactive">unactive</option>
   </select>
</form>
 <br><br>
<table class="table table-bordered">
<tr><td>product_id</td>
<td>product_name</td>
<td>quantity</td>
<td>prize_per_unit</td>
<td>description</td>
<td>insert_date</td>
<td>status</td>
<td>action</td>

</tr>
<?php 
if(count($result)==0){
	?>
<tr>
 <td colspan="6"><?php echo $this->lang->line('no_record_found');?></td>
</tr>	
	
	
	
<?php } ?>
<?php
foreach($result as $row){
?>
<tr>
<td><?php echo $row->product_id;?></td>
<td><?php echo $row->product_name;?></td>
<td><?php echo $row->quantity;?></id>
<td><?php echo $row->prize_per_unit;?></id>
<td><?php echo $row->description;?></id>
<td><?php echo date('d-m-Y',$row->insert_date);?></id>
<td><?php echo $row->status;?></td>
<td><?php echo $row->action;?></td>


</tr>

<?php
}  ?>
</table>

<td><a href="<?php echo site_url('Second_controller/nav_list/'); ?>"class="btn btn-default">submit</a></td>	
<td><a href="<?php echo site_url('Second_controller/cen/'); ?>"class="btn btn-default">form</a></td>

</body>


</head>
</html>
	

