<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>ADMIN PAGE</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

  <div id="container">	
  <?php if($this->session->flashdata('message')){ 
			 ?>
			 <div class="message">
			 <?php echo $this->session->flashdata('message'); ?><br><br>
			  </div>
			 <?php
			 } ?>

<div id="body">

     <div class="panel panel-default">
    <form method="post" action="<?php echo site_url('Last_controller/show');?>">   
    <div class="panel-body">
    <div class="form-group">
        <label for="username">username:-</label>
    <input type="text" class="form-control" name="username" required>
    <label for="password">password</label>
    <input type="password" class="form-control" name="password" required><br>
    <button type="login" class="btn btn-default">login</button>
   
</div>
</div>
</div>
</form>

	<a href="<?php echo site_url('Last_controller/logout'); ?>" class="btn btn-success">logout</a>
      <span onClick='javascript:Myfunction();' class="btn btn-info">ajax</span>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</body>
</html>
<script>
function  Myfunction(){
	//console.log('dd'); 
	var formData = {val:'12'};
	$.ajax({
		 type: "POST",
		 data : formData,
			url:"http://localhost/new_project/index.php/last_controller/ajax_list/",
		success: function(data){
		 
			},
			
		});
	
}

</script>
