<html lang="en">  
<head>
  <style>
 
</style>
</head>
<title></title>

<body>


<div class="table">
    <table style="border:20px solid black;width:100%;">
       
            <tr class="pdf_border">
                <th>username</th><br>
                <th>password</th> 
                               
                
            </tr>
      
       
                    <tr>
			
                       <td><?php echo $result['username']; ?></td>
                        <td><?php echo $result['password']; ?></td> 
                        
			            
  
</tr>


</table>
   				
</div> 
</body>
</html>


