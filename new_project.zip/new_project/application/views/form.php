<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>welcome to php</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	
	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div id="container">
	<h1>Registerstation Form</h1>

<div id="body">
<form method="post" action="<?php echo site_url('New_controller/form_insert/');?>">
	<div class='contact'><h1>HELLO EVERYONE</h1></div>
	<div class="panel panel-default" id="contact">
     <div class="panel-body">
    <div class="form-group">
    <label for="studentname">student Name:</label>
    <input type="studentname" class="form-control" name="studentname" required id="studentname">
    <label for="age">age:</label>
    <input type="age"  name="age" class="form-control" required  id="age">
    <label for="gender">gender:</label>
    <input type="gender"  name="gender" class="form-control" required  id="gender">
     <label for="mobileno">mobileno:</label>
     <input type="mobileno"  name="mobileno" class="form-control" required  id="mobileno">
     <label for="address">address:</label>
    <input type="address"  name="address" class="form-control" required  id="address">
     <label for="city">select your city:</label><br>
 <select name="city"  name="city" class="form-control" required  id="city">
          <option value="Punjab">Punjab</option>
          <option value="Canada">Canada</option>
	  <option value="Australia">Australia</option>
	  <option value="America">America</option>
	  <option value="London">London</option>
</select><br>
    <label><input type="checkbox"> Remember me</label><br>
    <button type="submit" class="btn btn-default">Submit</button>
 
	</div>
	</div>
    </div>

</form>

	 <p><a href="<?php echo site_url('New_controller/main_new/') ?>">submit</a>.</p>
  	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
</div>
</body>
</html>
<html>
