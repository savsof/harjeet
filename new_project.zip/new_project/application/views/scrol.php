
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<head>

<body>
<table class="table table-bordered">
<tr><td>studentname</td>
<td>age</td>
<td>gender</td>
<td>mobile</td>
<td>address</td>
<td> action </td>
<td> action </td>
<td> action </td>
</tr>
<?php 
if(count($result)==0){
	?>
<tr>
 <td colspan="6"><?php echo $this->lang->line('no_record_found');?></td>
</tr>	
	
	
	
<?php } ?>
<?php
foreach($result as $key => $val){
?>
<tr>
<td><?php echo $val['studentname'];?></td>
<td><?php echo $val['age'];?></td>
<td><?php echo $val['gender'];?></td>
<td><?php echo $val['mobileno'];?></td>
<td><?php echo $val['address'];?></td>
<td><a href="<?php echo site_url('New_controller/get_new/'.$val['s_id']); ?>"class="btn btn-default">view</a></td>
<td><a href="<?php echo site_url('New_controller/edit_new/'.$val['s_id']); ?>" class="btn btn-default">edit</a></td>
<td><a href="<?php echo site_url('New_controller/remove/'.$val['s_id']); ?>" class="btn btn-default">delete</a></td>
</tr>

<?php
}  ?>
</table>
	


</body>


</head>
</html>
	

