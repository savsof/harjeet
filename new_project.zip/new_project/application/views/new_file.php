<html lang="en">  
<head>
  <style>
 
</style>
</head>


<body>


<div class="table">
    <table style="border:20px solid black;width:100%;">
       
            <tr class="pdf_border">
                <th style="border:5px solid red;">username</th><br>
                <th style="border:5px solid green">email</th> 
                <th style="border:5px solid blue">contactno</th>
                <th style="border:5px solid pink">status</th>                      
                
            </tr>
      
       
<?php 
if(count($result)==0){
	?>
<tr>
 <td colspan="6"><?php echo $this->lang->line('no_record_found');?></td>
</tr>	
	
	
	
<?php } ?>
<?php
foreach($result as $row =>$val){
?>                 <tr>
                       <td style="border:5px solid red"><?php echo $val['username']; ?></td>
                        <td style="border:5px solid green"><?php echo $val['email']; ?></td> 
                        <td style="border:5px solid blue"><?php echo $val['contactno']; ?></td>
                        <td style="border:5px solid pink"><?php echo $val['status']; ?></td>
			            
  
</tr>

<?php
} ?>
</table>
   				
</div> 
</body>
</html>
