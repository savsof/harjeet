<html lang="en">
<head>
  <title>user record</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 
<div class="container">
    <div class="panel panel-default">
    <form method="post" action="<?php echo site_url('Pass_controller/update_new/'.$result['u_id']);?>">
     <div class="panel-body">
    <div class="form-group">
    <label for="username">username:</label>
    <input type="text" class="form-control" name="username" value="<?php echo $result['username']; ?>">
     <label for="pwd">password:</label>
    <input type="pwd" class="form-control" name="password" value="<?php echo $result['password']; ?>">
    <label for="email">email:</label>
    <input type=email" class="form-control" name="email" value="<?php echo $result['email']; ?>" >
   <label for="contactno">contactno:</label>
   <input type="contactno" class="form-control" name="contactno" value="<?php echo $result['contactno']; ?>" ><br>
     <button type="submit" class="btn btn-default">Submit</button>
	</div>
	</div>
    	</form>
  </div>
</div>

</body>
</html>

