<?php
Class Third_model extends CI_Model
{

function insert_data()
{

//print_r($_POST);die;
$userdata = array(
'username' => $this->input->post('username'),
'password'=>$this->input->post('password'),
'email'=>$this->input->post('email'),
'contactno'=>$this->input->post('contactno')
);
if($this->db->insert('user',$userdata)){
return true;
}
else
{
return false;
}
}


}

?>
