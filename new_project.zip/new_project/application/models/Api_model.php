<?php
Class Api_model extends CI_Model
{



}
?>
