<?php
Class Project_model extends CI_Model
{

function form_insert()
{
//print_r($_POST);die;
$insert_data = array(
'studentname' => $this->input->post('studentname'),
'age' => $this->input->post('age'),
'gender' => $this->input->post('gender'),
'mobileno' => $this->input->post('mobileno'),
'address' => $this->input->post('address'),
'city'=>$this->input->post('city')
);

if($this->db->insert('student_record', $insert_data)){
return true;
}else{
return false;
}
//$data['message'] = 'Data Inserted Successfully';

}
function std_list()
{

        $this->db->select('*');            
        $query = $this->db->get('student_record');
        return $query->result_array();

}
function get_std($s_id)
{
$this->db->where('s_id',$s_id);
$query=$this->db->get('student_record');
return $query->row_array();


}
function product_std($status)
{

if($this->input->post('search_type')){//echo "<pre>";print_r($_POST);die;
$this->db->like($this->input->post('search_type'),$this->input->post('search'));
}
if($status='active'){
//echo "hhh";die;
$this->db->where("(user.status='user')");
}
else if($status='unactive'){
$this->db->where("(user.status='admin')");
}
$this->db->order_by('u_id','desc');	 
 $query=$this->db->get('user');
if($query-> num_rows() >=1){
return $query->result();
}else{
return false;
}
}
 function edit_std($s_id)
{
$this->db->where('u_id',$s_id);
$query=$this->db->get('user');
return $this->row_array();
}




function update_std($s_id)
{
$user_data = array(
'studentname' => $this->input->post('studentname'),
'age' => $this->input->post('age'),
'gender' => $this->input->post('gender'),
'mobileno' => $this->input->post('mobileno'),
'address' => $this->input->post('address')
);
$this->db->where('s_id',$s_id);
if($this->db->update('student_record', $user_data)){
return true;
}else{

return false;
}

}

function remove($s_id)
{
$this->db->where('s_id',$s_id);
$query=$this->db->delete('student_record');
//return $this->row_array();
}

}
?>

