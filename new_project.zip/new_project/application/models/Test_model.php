<?php
Class Test_model extends CI_Model
{

function form_insert()
{
//print_r($_POST);die;
$insert_data = array(
'username' => $this->input->post('username'),
'password'=>md5($this->input->post('password')),
'email'=>$this->input->post('email'),
'contactno'=>$this->input->post('contactno'),
'status'=>$this->input->post('status'),
'category'=>$this->input->post('category')
);
if($this->db->insert('user',$insert_data)){
return true;
}
else
{
return false;
}

}
function product_std()
{

if($_POST['search_type']!=''){ //echo "<pre>";print_r($_POST);die;
$this->db->like($this->input->post('search_type'),$this->input->post('search'));
}

$this->db->order_by('u_id','desc');	 
 $query=$this->db->get('user');
if($query-> num_rows() >=1){
return $query->result_array();
}else{
return false;
}
}


function std_list($limit)
{
$this -> db -> limit($this->config->item('number_of_rows'),$limit);
        $this->db->select('*');            
        $query = $this->db->get('user');
        return $query->result_array();

}

 function edit_std($u_id)
{
$this->db->where('u_id',$u_id);
$query=$this->db->get('user');
return $query->row_array();
}




function update_std($u_id)
{
$user_data = array(
'username' => $this->input->post('username'),
'password' => $this->input->post('password'),
'email' => $this->input->post('email'),
'contactno' => $this->input->post('contactno')
);
$this->db->where('u_id',$u_id);
if($this->db->update('user', $user_data)){
return true;
}else{

return false;
}

}

function remove($u_id)
{
$this->db->where('u_id',$u_id);
$query=$this->db->delete('user');
//return $this->row_array();
}
function show_data()
{

$query=$this->db->get('user');
return $query->num_rows();
}


 function add_new($u_id)
{
$this->db->get('user',$data);
return $query->num_array();

}
function data_show()
{
$query=$this->db->get('user');
return $query->result_array();
}
function pdf_show($u_id)
{

$query=$this->db->get('user');
return $query->result_array();

}

function show_jb() 
{
$this->db->join("user","user.u_id=savsoft_user.username.a_id"); 
$query = $this->db->get('savsoft_user');
return $query->result_array();
}






}

?>
