<?php
Class Product_model extends CI_Model
{

function product_insert()
{
//$date=date('d-m-Y',time());
//print_r($_POST);die;
$userdata = array(
'product_name' => $this->input->post('product_name'),
'quantity' => $this->input->post('quantity'),
'prize_per_unit' => $this->input->post('prize_per_unit'),
'description' => $this->input->post('description'),
'insert_date' => strtotime($this->input->post('insert_date')),
'status' => $this->input->post('status'),

);

if($this->db->insert('product_record', $userdata)){
return true;
}else{
return false;
}
}
 function product_std($status)
{

if($this->input->post('search_type')){//echo "<pre>";print_r($_POST);die;
$this->db->like($this->input->post('search_type'),$this->input->post('search'));
}
if($status='active'){
//echo "hhh";die;
$this->db->where("(product_record.status='active')");
}
else if($status='unactive'){
$this->db->where("(product_record.status='unactive')");
}
$this->db->order_by('product_id','desc');	 
 $query=$this->db->get('product_record');
if($query-> num_rows() >=1){
return $query->result();
}else{
return false;
}
}


function product_admin()

{
date('y-m-d');
$userdata = array(
'username' => $this->input->post('username'),
'email' => $this->input->post('email'),
'password' => $this->input->post('password'),
'date'=>strtotime($this->input->post('date'))
);
if($this->db->insert('admin_record',$userdata)){
return true;
}else{
return false;
}
 }
  
function upload()
{

$userdata = array(
'user_name' => $this->input->post('user_name'),
'password' => $this->input->post('password')

);
if($this->db->upload('new_file',$userdata)){
return true;
}else{
return false;
}


}


}   




?>
                                                                                                                                                                                                                                                                    
