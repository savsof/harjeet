<?php
Class Insert_model extends CI_Model
{

function form_insert()
{
//print_r($_POST);die;
$insert_data = array(
'student_name' => $this->input->post('studentname'),
'class' => $this->input->post('class'),
'rollno' => $this->input->post('rollno'),
'batch' => $this->input->post('batch'),
'course' => $this->input->post('course'),
'email' => $this->input->post('email'),
'password' => $this->input->post('password'),
'address' => $this->input->post('address'),
'contactno' => $this->input->post('contactno'),
);

if($this->db->insert('record', $insert_data)){
return true;
}else{
return false;
}
//$data['message'] = 'Data Inserted Successfully';

}
function std_list()
{

        $this->db->select('*');            
        $query = $this->db->get('record');
        return $query->result_array();

}

}
?>
