<?php
Class Last_model extends CI_Model
{

function form_insert($feedbackval)
{
//print_r($_POST);die;
$insert_data = array(
'username' => $this->input->post('username'),
'password'=>md5($this->input->post('password')),
//'filename' =>$feedbackval

);
if($this->db->insert('savsoft_user',$insert_data)){
return true;
}
else
{
return false;
}
}

function user_list()
{

        $this->db->select('*');            
        $query = $this->db->get('savsoft_user');
    //print_r($this->db->last_query());die;
       return $query->result_array();
      

}
function show_data()
{
$username=$_POST['username'];
$password=$_POST['password'];                   

$this->db->where('username',$username);
$this->db->where('password',md5($password));
$query=$this->db->get('savsoft_user');

if($query->num_rows() >=1)
{
return $query->row_array();
}
else
{
return false;
}

}

function view_data($a_id)
{
$this->db->where('a_id',$a_id);
$query=$this->db->get('savsoft_user');
return $query->row_array();
}

}
?>
