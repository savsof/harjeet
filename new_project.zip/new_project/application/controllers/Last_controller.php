<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Last_controller extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->model('Last_model');
}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

    public function index()
{
               
 if($this->input->post('username')){

  $data['result']=$this->Last_model->form_insert($feedbackval);

}
     $this->load->view('user_file',$data);
 
    
}


public function user_new()
{
  $data['result']=$this->Last_model->user_list();
//echo "<pre>";print_r($data['result']);die;
  $this->load->view('admin_list',$data);

}




public function show()
{
//print_r($_POST);die;
$result=$this->Last_model->show_data();

$newdata = array(
'username'  => $result['username'],
        
       
);

$this->session->set_userdata('harjeet',$newdata);
$log=$this->session->userdata('harjeet');

   

//print_r($log);die;

$this->load->view('login',$data);
if($result!=false){
$this->session->set_flashdata('message',"User login successfully");
//redirect('Last_controller/user_new');
}
}


public function logout() {
//print_r($_POST);die;
$result=$this->Last_model->not_show();

$newdata = array(
'username'  => $result['username'],
     
   
);
$log=$this->session->userdata('harjeet');
$this->session->unset_userdata('harjeet',$newdata);
$this->session->sess_destroy ();
 //print_r($log);die;   		
$this->load->view('login',$data);
 if($this->session->userdata('u_id') == '')
$this->session->set_flashdata('message',"user logout successfully");
}			    	
			   

 

public function ajax_list()
{
$data['title']="ajax";
 $this->load->view('nav_ajax',$data);

}
public function upload()
{

	if($_FILES['filename']['name']!=''){ 

$this->load->library('upload');

$config['upload_path'] = './upload';
$config['allowed_types'] = 'jpg|png|doc|docx|pdf|jpeg';
$config['max_size']     = '400';
$this->load->library('upload', $config);
$this->upload->initialize($config);
 

//image upload start here 
 if ( ! $this->upload->do_upload('filename'))
                {

$this->session->set_flashdata('message', "Unable to submit!");
			redirect('Last_controller/user_list/');
   //$uerrormsg.="<p>".strip_tags($this->upload->display_errors())." ( ".ucfirst(str_replace('_',' ',$kl))." )</p>";  
 
                }
                else
                {
 
                 $ufile=$this->upload->data();
$filename=$ufile['file_name'];
$oldpath=$config['upload_path'].'/'.$filename;
$feedbackval=time().''.$ufile['file_ext'];

$filenamenull="";
$nname=$config['upload_path'].'/'.$feedbackval;

rename($oldpath,$nname);
}



}
else{
$feedbackval="";

}
$this->load->Last_model($feedbackval);
redirect('Last_controller');
// image upload end here 

// model
//redirect after uploaded files



}

function view_pdf($a_id)
{
	
$data['result']= $this->Last_model->view_data($a_id);

$this->load->library('pdf');
$this->pdf->load_view('pdf_show_data',$data);
$this->pdf->render();
$filename=date('Y-M-d_H:i:s',time()).".pdf";
$this->pdf->stream($filename);
}



}
?>
