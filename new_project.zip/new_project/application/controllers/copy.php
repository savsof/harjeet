
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
 
<head>

<body>
<table class="table table-bordered">
<tr><td>studentname</td>
<td>Class</td>
<td>roll no</td>
<td>Batch</td>
<td>Email</td>
<td>course</td>
<td>Address</td>
<td>contactno</td>
</tr>
<?php 
if(count($result)==0){
	?>
<tr>
 <td colspan="6"><?php echo $this->lang->line('no_record_found');?></td>
</tr>	
	
	
	
}
<?php
foreach($result as $key => $val){
?>
<tr>
<tr><td><?php echo $val['studentname'];?></td>
<td><?php echo $val['class'];?></td>
<td><?php echo $val['rollno'];?></td>
<td><?php echo $val['betch'];?></td>
<td><?php echo $val['email'];?></td>
<td><?php echo $val['course'];?></td>
<td><?php echo $val['address'];?></td>
<td><?php echo $val['contactno'];?></td>

<?php
}  ?>
</table>




</body>


</head>
</html>
	

