<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class New_controller extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->model('Project_model');
//$this->load->model('insert_model');
}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function form_insert ()

	{
		if($this->input->post('studentname')){

	$data['result']=$this->Project_model->form_insert();
		}
	$this->load->view('form.php');
		

}
 public function main_new()
{
$data['result']= $this->Project_model->std_list();
//echo "<pre>";print_r($data['result']);die;
	$this->load->view('scrol.php',$data);			


} 
public function get_new($s_id)
{
$data['result']=$this->Project_model->get_std($s_id);
//echo "<pre>";print_r($data['result']);die;
$this->load->view('view.php',$data);
}
public function edit_new($s_id)	
{
$data['result']=$this->Project_model->get_std($s_id);
//echo "<pre>";print_r($data['result']);die;
$this->load->view('show.php',$data);

}
public function update_new($s_id)
{
$data['result']=$this->Project_model->update_std($s_id);
redirect('New_controller/edit_new/'.$s_id);
}
public function remove($s_id)
{
$data['result']=$this->Project_model->remove($s_id);
redirect('New_controller/main_new/');
}
}
?>

