<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Second_controller extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->model('Product_model');
 $this->load->helper(array('form', 'url'));
//$this->load->model('insert_model');
}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index ()

	{
		if($this->input->post('product_name')){

	$data['result']=$this->Product_model->product_insert();
		}
	$this->load->view('enquiry_report.php');
	$this->load->view('file.php');
	

}
 public function nav_list($status='active')
{
//print_r($_POST);die;
//print_r($_POST); die;
$data['status']=$status;
$data['result']=$this->Product_model->product_std($status);
//print_r($data);die;
 $this->load->view('std_list',$data);

}
public function cen()
{
 $this->load->view('quickstart');
}
public function edit_new($u_id)	
{
$data['result']=$this->Test_model->edit_std($u_id);
//echo "<pre>";print_r($data['result']);die;
$this->load->view('test_show',$data);

}
public function admin_list()
{
$data['result']=$this->Product_model->product_admin();
 redirect('Second_controller'); 
      

    
}

 public function add_upload()
        {
		$data['result']=$this->Product_model->upload();
                $this->load->view('user_file', array('error' => ' ' ));
        }

function product_download($product_id){
	//$data['currency']= $this->product_model->getcurrencycode();
	//$data['result'] = $this->product_model->get_productdetail($prod_id); 
	$data['result']=$this->Product_model->get_std_list($product_id);
$this->load->library('pdf');
$this->pdf->load_view('pdf_file',$data);
$this->pdf->render();
$filename=date('Y-M-d_H:i:s',time()).".pdf";
$this->pdf->stream($filename);
}

  public function do_upload()
        {
                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());

                        $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                        $this->load->view('upload_success', $data);
                }
	                
        }



}
?>





