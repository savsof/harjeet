<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pass_controller extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->model('Test_model');
$this->load->library('form_validation');
}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index ()

	{
		$this->form_validation->set_rules('email', 'email', 'trim|required|valid_email|xss_clean');
		if($this->input->post('username')){

	$data['result']=$this->Test_model->form_insert();
	
		}
	$this->load->view('test.php');
		

}

 public function main_new($limit='0')
{
$data['result']= $this->Test_model->std_list($limit);
//echo "<pre>";print_r($data['result']);die;
	$this->load->view('test_main.php',$data);
$data['limit']='$limit';			


} 
  public function nav_list()
{
//print_r($_POST);die;

//$data['status']=$status;
$data['result']=$this->Test_model->product_std();
$this->load->view('test_main',$data);

}

public function edit_new($u_id)	
{
$data['result']=$this->Test_model->edit_std($u_id);
//echo "<pre>";print_r($data['result']);die;
$this->load->view('test_show',$data);

}
public function update_new($u_id)
{

$data['result']=$this->Test_model->update_std($u_id);

redirect('Pass_controller/edit_new/'.$u_id);
}
public function remove($u_id)
{
$data['result']=$this->Test_model->remove($u_id);
redirect('Pass_controller/main_new');
}
public function show()
{

$data['showdata']=$this->Test_model->show_data();
//print_r($data['showdata']);die;
$this->load->view('login_form',$data);

}
function product_download($u_id)
{	
	$data['result']= $this->Test_model->edit_std($u_id);
$this->load->library('pdf');
$this->pdf->load_view('new_file',$data);
//$this->load->view('pdf_file',$data);
$this->pdf->render();
$filename=date('Y-M-d_H:i:s',time()).".pdf";
$this->pdf->stream($filename);
}
function csvdownload($u_id)
{
	$val= $this->Test_model->edit_std($u_id);
	//echo "<pre>";print_r($data['result']);die;
$this->load->helper('download');
$csvdata="username,email,contactno,status  \r\n";
	foreach($data['result'] as $key=>$val){
$csvdata.=$val['username'].",".$val['email'].",".$val['contactno'].",".$val['status']." \r\n";
	}
	$filename=time().'.csv';
force_download($filename, $csvdata);
}

function file_download()
{
$data['result']=$this->Test_model->data_show();
//print_r($data['result']);die;
$this->load->helper('download');
$csvdata="Username, Email,Contactno,Status  \r\n";	
foreach($data['result'] as $key=>$val){
$csvdata.=$val['username'].",".$val['email'].",".$val['contactno'].",".$val['status']." \r\n";
}
$filename=time().'.csv';
force_download($filename,$csvdata);
}
function download($u_id)
{	
$data['result']= $this->Test_model->pdf_show($u_id);
$this->load->library('pdf');
$this->pdf->load_view('new_file',$data);
//$this->load->view('pdf_file',$data);
$this->pdf->render();
$filename=date('Y-M-d_H:i:s',time()).".pdf";
$this->pdf->stream($filename);
}
function insert()
{
	
	$data['result']=$this->Test_model->show_jb();  
	$this->load->view('pass_controller',$data);
	
}
	function generateexcelreports(){
	
	$data['result'] = $this->branch_model->generateexcelreports();
	//echo "<pre>";print_r($_POST);echo "<pre>";print_r($data['result']);die;
		
/* excel gen starts */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');
if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');
/** Include PHPExcel */
require_once 'application/helpers/PHPExcel/Classes/PHPExcel.php';
// Create new PHPExcel object
$objPHPExcel = new PHPExcel();
// Set document properties
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");
 // set width of columns
$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
 $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
 $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
 $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(35);
 $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(13);
 $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
 $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(8);
 $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(13);


 
// Add a drawing to the worksheetecho date('H:i:s') . " Add a drawing to the worksheet\n";


 
$objPHPExcel->getActiveSheet()->getStyle("C1:E1")->getFont()->setSize(16);
$objPHPExcel->getActiveSheet()->getStyle("C2:E2")->getFont()->setSize(16);
 $objPHPExcel->getActiveSheet()
    ->getStyle('C1:E1')
    ->getFill()
  ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setRGB('FFC0C0C0');
 
    $objPHPExcel->getActiveSheet()
    ->getStyle('A3:Q3')
    ->getFill()
  ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setRGB('FAEBD7');
$objPHPExcel->getActiveSheet()
    ->getStyle('C1:E1')
    ->getAlignment()
    ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);


$objPHPExcel->getActiveSheet()
    ->getStyle('A3:Q3')
    ->getAlignment()
    ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

//$objPHPExcel->getActiveSheet()->getRowDimension('4')->setRowHeight(50); 


$objPHPExcel->getActiveSheet()
    ->getStyle('C2:E2')
    ->getAlignment()
    ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    // bold text//


    $objPHPExcel->getDefaultStyle()->applyFromArray(array(
                'borders' => array(
                    'allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN,
                                          
                                          )
                )
            ));


$objPHPExcel->getDefaultStyle()->applyFromArray(array(
                'borders' => array(
                    'allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN,
                                          
                                          )
                )
            ));
//end//
//wrap text//
$objPHPExcel->getActiveSheet()->getStyle('F')->getAlignment()->setWrapText(true);
$objPHPExcel->getActiveSheet()->getStyle('K')->getAlignment()->setWrapText(true);
$objPHPExcel->getActiveSheet()->getStyle('L')->getAlignment()->setWrapText(true);
// MAIN heading 
$gdImage = imagecreatefromjpeg('');
$objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
$objDrawing->setName('Sample image');
$objDrawing->setDescription('Sample image');
$objDrawing->setImageResource($gdImage);
$objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
$objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
$objDrawing->setHeight(40);
$objDrawing->setCoordinates('B1');
$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', 'Turning Point Student List'); 

if(isset($_POST['to_date'])){
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C2', 'Date: '.$_POST['to_date'].' - '.$_POST['from_date']); 
}


$gdImage2 = imagecreatefromjpeg('');
$objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
$objDrawing->setName('Sample image2');
$objDrawing->setDescription('Sample image2');
$objDrawing->setImageResource($gdImage2);
$objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
$objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
$objDrawing->setHeight(50);
$objDrawing->setCoordinates('F1');
$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
// set heading height
$objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(40);
$objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(30);

// set headings
 $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'usrname'); 		
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'password'); 
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'emal'); 
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'contactno'); 
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'status'); 
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'category'); 
	
// SET VALUES 


	foreach($data['result'] as $key=>$val){


	// NOTE ADD MORE THAN ONE VALUE OF MAIN HEADING YOU ADDED.
	// SUPPOSE YOU 	ADDED 2 MAIN HEADING (ROWS) THEN USE $KEY+3
	
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.($key+4),$val['username']);		

$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($key+4),$val['password']);
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($key+4),$val['email']);
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.($key+4),$val['contactno']);
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.($key+4),$val['status']);
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('J'.($key+4),$val['category']);
$objPHPExcel->getActiveSheet()->getRowDimension($key+4)->setRowHeight(30);
}

 // Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Student_report');
// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);
// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="01simple.xls"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');
// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

	
	}




}
?>

